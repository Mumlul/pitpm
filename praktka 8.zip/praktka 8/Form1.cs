﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace praktka_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0: pictureBox1.Image = Image.FromFile(@"C:\Users\plosk\OneDrive\Рабочий стол\praktka 8\зима.jpg");
                    break;
                case 1:
                    pictureBox1.Image = Image.FromFile(@"C:\Users\plosk\OneDrive\Рабочий стол\praktka 8\весна.jpg");
                    break;
                case 2:
                    pictureBox1.Image = Image.FromFile(@"C:\Users\plosk\OneDrive\Рабочий стол\praktka 8\осень.jpg");
                    break;
                case 3:
                    pictureBox1.Image = Image.FromFile(@"C:\Users\plosk\OneDrive\Рабочий стол\praktka 8\весна.jpg");
                    break;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(textBox1.Text);
            switch (comboBox2.SelectedIndex)
            {
                case 0:

                    MessageBox.Show($"{(a / 10000) * 5} р");
                    break;
                case 1:
                 
                    MessageBox.Show($"{(a / 10000) * 6} р");
                    break;
                case 2:
                  
                    MessageBox.Show($"{(a / 10000) * 7} р");
                    break;
                    case 3:
                   
                    MessageBox.Show($"{(a / 10000) * 8} р");
                    break;
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox3.SelectedIndex)
            {
                case 0:
                    label1.ForeColor = System.Drawing.Color.Magenta;
                    break;
                case 1:
                    label1.ForeColor = System.Drawing.Color.Yellow;
                    break;
                case 2:
                    label1.ForeColor = System.Drawing.Color.Green;
                    break;

            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (listBox1.SelectedIndex)
            {
                case 0:
                    BackColor = System.Drawing.Color.Red;
                    break;
                case 2:
                    BackColor = System.Drawing.Color.Blue;
                    break;
                case 1:
                    BackColor = System.Drawing.Color.Yellow;
                    break;
            }
        }


        int count = 0;
        int count_nc = 0;
        int count_ch = 0;
        int sum = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
           
            for(int i = 1; i < 100; i++)
            {
                string s = ""+i;
                if (s.Contains("0")) 
                {
                    listBox2.Items.Add(s);
                    count++;
                    sum += i;
                    if (i % 2 == 0) count_ch++;
                    else count_nc++;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox2.Items.Add("кол-во:"+count);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox2.Items.Add("кол-во нечетных:" + count_nc);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox2.Items.Add("sum:" + sum);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox2.Items.Add("кол-во четных:" + count_ch);
        }
    }
}
